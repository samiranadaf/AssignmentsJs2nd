function openWindow() {
  window.open("https://www.google.co.in/");
}
openWindow();
