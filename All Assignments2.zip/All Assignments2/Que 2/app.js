function windowContent() {
    return window.print();
}
windowContent();